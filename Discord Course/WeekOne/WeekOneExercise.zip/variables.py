'''1. Declare and Assign:'''

## Declare a variable age and assign your age to it.

age = 32

##  Declare three variables num1 , num2 , and sum . Assign values to num1 and num2 , then calculate the sum and store it in sum.
num1 = 5
num2 = 15

sum = num1 + num2
print(sum)
